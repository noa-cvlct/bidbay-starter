export const JWT_SECRET = 'THE_JWT_SECRET'
