// Noms et numéros d'étudiant
export const authors = ["John Doe (12345678)", "Jane Doe (12345678)"];

// Groupe
export const group = 0;
